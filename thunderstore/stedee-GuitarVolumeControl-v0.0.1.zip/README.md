# Guitar Volume Control?

A mod to add a setting for the guitar's volume

## Install

Either install automatically through Thunderstore or download the zip file and do it manually.
Just place the folder extracted from the zip into your mod folder

## Dependencies

[GDWeave](https://thunderstore.io/c/webfishing/p/NotNet/GDWeave/)
